from django.apps import AppConfig


class EshopProductsCommentsConfig(AppConfig):
    name = 'eshop_products_comments'
    verbose_name = 'ماژول نظرات کاربران'
