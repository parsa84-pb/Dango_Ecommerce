from django.apps import AppConfig


class EshopProductCategoryConfig(AppConfig):
    name = 'eshop_product_category'
    verbose_name = 'ماژول دسته بندی محصولات '

