from django.apps import AppConfig


class EshopProductsConfig(AppConfig):
    name = 'eshop_products'
    verbose_name = 'ماژول محصولات '
