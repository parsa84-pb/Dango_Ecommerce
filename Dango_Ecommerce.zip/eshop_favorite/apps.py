from django.apps import AppConfig


class EshopFavoriteConfig(AppConfig):
    name = 'eshop_favorite'
