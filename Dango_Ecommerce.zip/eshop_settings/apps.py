from django.apps import AppConfig


class EshopSettingsConfig(AppConfig):
    name = 'eshop_settings'
    verbose_name = 'ماژول تنظیمات سایت '
