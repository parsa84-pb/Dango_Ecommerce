from django.apps import AppConfig


class EshopContactConfig(AppConfig):
    name = 'eshop_contact'
    verbose_name = 'ماژول تماس با ما'

